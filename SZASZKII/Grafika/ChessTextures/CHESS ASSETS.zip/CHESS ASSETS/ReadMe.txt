You are free to use these assets for your personal or comercial games. No credit required. (CC0)



If you would be interested in future assets, feel free to like or follow any of my accounts:


Instagram: bz.gamedev
https://bzgamedev.itch.io
Discord: gchoc#2407

Thank you for your support 